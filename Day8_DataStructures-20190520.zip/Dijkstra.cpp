// A C++ program for Dijkstra's single source shortest path algorithm. 
// The program is for adjacency matrix representation of the graph 
  
#include <limits.h> 
#include <stdio.h> 
  

#define MAX 6 
  
int minDistance(int dist[], bool sptSet[]) 
{ 
    int min = INT_MAX, min_index; 
  
    for (int v = 0; v < MAX; v++) 
        if (sptSet[v] == false && dist[v] <= min) 
            min = dist[v], min_index = v; 
  
    return min_index; 
} 
  

int printSolution(int dist[], int n) 
{ 
    printf("Vertex   Distance from Source\n"); 
    for (int i = 0; i < MAX; i++) 
        printf("%d <-- %d\n", i, dist[i]); 
	
	return 0;
} 


void dijkstra(int graph[MAX][MAX], int src) 
{ 
    int dist[MAX]; 
    bool sptSet[MAX]; 
    for (int i = 0; i < MAX; i++) 
        dist[i] = INT_MAX, sptSet[i] = false; 
  

    dist[src] = 0; 
    for (int count = 0; count < MAX - 1; count++) { 
        int u = minDistance(dist, sptSet); 
        sptSet[u] = true; 
        for (int v = 0; v < MAX; v++) 
            if (!sptSet[v] && graph[u][v] && dist[u] != INT_MAX 
                && dist[u] + graph[u][v] < dist[v]) 
                dist[v] = dist[u] + graph[u][v]; 
    } 
  

    printSolution(dist, MAX); 
} 
  

int main() 
{ 
	int matrx[MAX][MAX]={0},i,j,n,u;
	
	for(int rCnt=0;rCnt<MAX;rCnt++){
		for(int cCnt=0;cCnt<MAX;cCnt++)	
			printf("%d ",matrx[rCnt][cCnt]);
		printf("\n");
	}
	
	matrx[0][1]=1; matrx[0][3]=5;matrx[1][2]=6;
	matrx[2][3]=8;matrx[2][4]=3;matrx[3][4]=4;
	matrx[4][5]=5;
	
	printf("After: \n");
	for(int rCnt=0;rCnt<MAX;rCnt++){
		for(int cCnt=0;cCnt<MAX;cCnt++)	
			printf("%d ",matrx[rCnt][cCnt]);
		printf("\n");
	}
	
	dijkstra(matrx,0);
  
    return 0; 
} 
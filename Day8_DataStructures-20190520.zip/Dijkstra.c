#include<stdio.h>
#define INFINITY 9999
#define MAX 6
 
void dijkstra(int G[MAX][MAX],int n,int startnode);
 
int main()
{
	int matrx[MAX][MAX]={0};
	
	for(int rCnt=0;rCnt<MAX;rCnt++){
		for(int cCnt=0;cCnt<MAX;cCnt++)	
			printf("%d ",matrx[rCnt][cCnt]);
		printf("\n");
	}
	matrx[0][1]=1; matrx[0][3]=5;matrx[1][2]=6;
	matrx[2][3]=8;matrx[2][4]=3;matrx[3][4]=4;
	matrx[4][5]=5;
	
	printf("After: \n");
	for(int rCnt=0;rCnt<MAX;rCnt++){
		for(int cCnt=0;cCnt<MAX;cCnt++)	
			printf("%d ",matrx[rCnt][cCnt]);
		printf("\n");
	}
	
	dijkstra(matrx,MAX,0);
	
	return 0;
}
 
void dijkstra(int graph[MAX][MAX],int n,int startnode){
 
	int cost[MAX][MAX],distance[MAX],pred[MAX];
	int visited[MAX],count,mindistance,nextnode,i,j;

	for(i=0;i<MAX;i++)
		for(j=0;j<MAX;j++)
			if(graph[i][j]==0)
				cost[i][j]=INFINITY;
			else
				cost[i][j]=graph[i][j];

	for(i=0;i<MAX;i++)
	{
		distance[i]=cost[startnode][i];
		pred[i]=startnode;
		visited[i]=0;
	}
	
	distance[startnode]=0;
	visited[startnode]=1;
	count=1;
	
	while(count<n-1){
		mindistance=INFINITY;
		
		for(i=0;i<n;i++)
			if(distance[i]<mindistance&&!visited[i]){
				mindistance=distance[i];
				nextnode=i;
			}
		
		visited[nextnode]=1;
		for(i=0;i<n;i++)
			if(!visited[i])
				if(mindistance+cost[nextnode][i]<distance[i]){
					distance[i]=mindistance+cost[nextnode][i];
					pred[i]=nextnode;
				}
		count++;
	}
 

	for(i=0;i<n;i++)
		if(i!=startnode)
		{
			printf("\nDistance of node%d=%d",i,distance[i]);
			printf("\nPath=%d",i);
			
			j=i;
			do
			{
				j=pred[j];
				printf("<--%d",j);
			}while(j!=startnode);
	}
}